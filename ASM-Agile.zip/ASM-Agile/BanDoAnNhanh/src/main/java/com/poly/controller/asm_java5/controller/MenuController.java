package com.poly.controller.asm_java5.controller; // ⚠️ sửa đúng package của bạn

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/menu")
public class MenuController {

    // TEST CỨNG TRƯỚC (CHƯA CẦN DB)
    @GetMapping
    public String menuAll(Model model) {
        model.addAttribute("products", List.of());
        model.addAttribute("activeCategory", "all");
        return "menu";
    }

    @GetMapping("/{category}")
    public String menuByCategory(@PathVariable String category, Model model) {
        model.addAttribute("products", List.of());
        model.addAttribute("activeCategory", category);
        return "menu";
    }

    @GetMapping("/ga-ran")
    public String menuByGaRan(Model model) {
        model.addAttribute("products", List.of());
        model.addAttribute("activeCategory", "ga-ran");
        return "menu/ga-ran";
    }

    @GetMapping("/burger")
    public String menuByBurger(Model model) {
        model.addAttribute("products", List.of());
        model.addAttribute("activeCategory", "burger");
        return "menu/burger";
    }

    @GetMapping("/pizza")
    public String menuByPizza(Model model) {
        model.addAttribute("products", List.of());
        model.addAttribute("activeCategory", "pizza");
        return "menu/pizza";
    }
}
