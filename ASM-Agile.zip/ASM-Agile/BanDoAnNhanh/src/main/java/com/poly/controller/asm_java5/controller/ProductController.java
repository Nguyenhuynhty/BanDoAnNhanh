package com.poly.controller.asm_java5.controller;



import com.poly.controller.asm_java5.service.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/product")
public class ProductController {

    @GetMapping("/list")
    public String list() {
        return "product/list";
    }
    @GetMapping("/detail")
    public String detail() {
        return "product/detail";
    }
    @GetMapping("/Ga_Ran_Gion_Cay")
    public String Ga_Ran_Gion_Cay() {
        return "product/Ga_Ran_Gion_Cay";
    }
//    @GetMapping("/cart")
//    public String cart() {
//        return "product/cart";
//    }
    @GetMapping("/Pizza_Pepperoni")
    public String Pizza_Pepperoni() {
        return "product/Pizza_Pepperoni";
    }
    @GetMapping("/Combo_Gia_Dinh")
    public String Combo_Gia_Dinh() {
        return "product/Combo_Gia_Dinh";
    }
    @GetMapping("/Tra_Dao_Sa")
    public String Tra_Dao_Sa() {
        return "product/Tra_Dao_Sa";
    }
    @GetMapping("/Khoai_Tay_Chien")
    public String Khoai_Tay_Chien() {
        return "product/Khoai_Tay_Chien";
    }
    @GetMapping("/Ga_Ran_Truyen_Thong")
    public String Ga_Ran_Truyen_Thong() {
        return "product/Ga_Ran_Truyen_Thong";
    }

    @GetMapping("/ga-ran-cay-phomai")
    public String ga_ran_cay_phomai() {
        return "product/ga-ran-cay-phomai";
    }

    @GetMapping("/ga-ran-BBQ")
    public String ga_ran_BBQ() {
        return "product/ga-ran-BBQ";
    }

    @GetMapping("/ga-ran-tieu-den")
    public String ga_ran_tieu_den() {
        return "product/ga-ran-tieu-den";
    }

    @GetMapping("/ga-ran-mat-ong")
    public String ga_ran_mat_ong() {
        return "product/ga-ran-mat-ong";
    }

    @GetMapping("/Burger_Bo_Pho_Mai")
    public String Burger_Bo_Pho_Mai() {
        return "product/Burger_Bo_Pho_Mai";
    }

    @GetMapping("/Burger_Ga_Gion_Cay")
    public String Burger_Ga_Gion_Cay() {
        return "product/Burger_Ga_Gion_Cay";
    }

    @GetMapping("/Burger_dui_ga_nuong")
    public String Burger_dui_ga_nuong() {
        return "product/Burger_dui_ga_nuong";
    }
}
