package org.example.bvasm.controller;

import org.example.bvasm.entity.Product;
import org.example.bvasm.repository.ProductRepository;
import org.example.bvasm.service.CartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/shop")
public class ShopController {

    private final ProductRepository productRepository;
    private final CartService cartService;

    // Constructor inject bean
    public ShopController(ProductRepository productRepository,
                          CartService cartService) {
        this.productRepository = productRepository;
        this.cartService = cartService;
    }

    // Hiển thị danh sách sản phẩm
    @GetMapping("")
    public String shop(Model model) {
        model.addAttribute("items", productRepository.findAll());
        return "shop";
    }

    // Thêm vào giỏ
    @GetMapping("/add/{id}")
    public String addToCart(@PathVariable Integer id) {

        Product p = productRepository.findById(id).orElse(null);

        if (p != null) {
            cartService.add(p);
        }

        return "redirect:/cart/view";
    }
}