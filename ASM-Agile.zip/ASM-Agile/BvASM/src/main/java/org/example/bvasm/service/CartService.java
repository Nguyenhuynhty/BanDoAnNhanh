package org.example.bvasm.service;

import org.example.bvasm.entity.Product;
import org.example.bvasm.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CartService {

    private final ProductRepository repo;

    public CartService(ProductRepository repo) {
        this.repo = repo;
    }

    public Product getProductById(Integer id) {
        return repo.findById(id)   // ✔ gọi qua object repo
                .orElse(null);
    }

    public void add(Product p) {
    }

    public void remove(Integer id) {
    }

    public void update(Integer id, Integer qty) {
    }

    public void clear() {
    }
}