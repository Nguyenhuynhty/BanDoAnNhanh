//package org.example.bvasm.service;
//
//import org.example.bvasm.entity.Account;
//import org.example.bvasm.repository.AccountRepository;
//import org.springframework.stereotype.Service;
//
//@Service
//public class CustomUserDetailsService implements UserDetailsService {
//
//    private final AccountRepository accountRepository;
//
//    public CustomUserDetailsService(AccountRepository accountRepository) {
//        this.accountRepository = accountRepository;
//    }
//
//    @Override
//    public UserDetails loadUserByUsername(String username)
//            throws UsernameNotFoundException {
//
//        Account acc = accountRepository.findById(username)
//                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
//
//        return User.builder()
//                .username(acc.getUsername())
//
//                // ⚠ nếu password DB chưa mã hóa thì dùng {noop}
//                .password("{noop}" + acc.getPassword())
//
//                .roles(acc.getRole() ? "ADMIN" : "USER")
//                .disabled(!acc.getActivated())
//                .build();
//    }
//}