package org.example.bvasm.controller;

import org.example.bvasm.entity.Product;
import org.example.bvasm.repository.ProductRepository;
import org.example.bvasm.service.CartService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cart")
public class CartController {

    private final ProductRepository productRepository;
    private final CartService cartService;

    public CartController(ProductRepository productRepository,
                          CartService cartService) {
        this.productRepository = productRepository;
        this.cartService = cartService;
    }

    @GetMapping("/add/{id}")
    public String addToCart(@PathVariable Integer id) {

        Product p = productRepository.findById(id).orElse(null); // ✔ đúng

        if (p != null) {
            cartService.add(p);
        }

        return "redirect:/cart/view";
    }

    @GetMapping("/remove/{id}")
    public String remove(@PathVariable Integer id) {
        cartService.remove(id);
        return "redirect:/cart/view";
    }

    @PostMapping("/update")
    public String update(@RequestParam Integer id,
                         @RequestParam Integer qty) {
        cartService.update(id, qty);
        return "redirect:/cart/view";
    }

    @GetMapping("/clear")
    public String clear() {
        cartService.clear();
        return "redirect:/cart/view";
    }

    @GetMapping("/view")
    public String viewCart() {
        return "cart"; // trang cart.html
    }
}