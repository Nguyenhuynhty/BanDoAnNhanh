package org.example.bvasm.service;

import jakarta.servlet.http.HttpSession;
import org.example.bvasm.entity.Account;
import org.example.bvasm.repository.AccountRepository;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AccountRepository accountRepository;
    private final HttpSession session;

    public AuthService(AccountRepository accountRepository, HttpSession session) {
        this.accountRepository = accountRepository;
        this.session = session;
    }

    public boolean login(String username, String password) {
        Account acc = accountRepository.findById(username).orElse(null);

        if (acc != null && acc.getPassword().equals(password)) {
            session.setAttribute("user", acc);
            return true;
        }
        return false;
    }

    public void logout() {
        session.removeAttribute("user");
    }

    public Account getUser() {
        return (Account) session.getAttribute("user");
    }
}