package org.example.bvasm.DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/baove?useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8";

    private static final String USER = "root";
    private static final String PASS = "123456"; // đổi theo máy bạn

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("❌ Kết nối DB thất bại!");
            e.printStackTrace();
            return null;
        }
    }
}