package org.example.bvasm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PS45336_java5Application {

    public static void main(String[] args) {

        SpringApplication.run(PS45336_java5Application.class, args);
    }

}
