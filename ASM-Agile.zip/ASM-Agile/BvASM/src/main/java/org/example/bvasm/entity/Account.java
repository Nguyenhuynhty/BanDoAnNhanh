package org.example.bvasm.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Accounts")
@Data
public class Account {

    @Id
    private String username;

    private String password;
    private String fullname;
    private String email;
    private String photo;
    private Boolean activated;
    private Boolean role;
}