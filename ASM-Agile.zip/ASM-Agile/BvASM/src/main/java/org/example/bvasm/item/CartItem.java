package org.example.bvasm.item;

import lombok.*;
import org.example.bvasm.entity.Product;

//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class CartItem {
//    private Product product;
//    private int quantity;
//
//    public double getAmount() {
//        return product.getPrice() * quantity;
//    }
//}

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartItem {
    private Integer id;
    private String name;
    private double price;
    private int qty = 1;
    private String image;

    public double getTotal() {
        return price * qty;
    }
}