package org.example.bvasm.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Products")
@Data
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;
    private String image;
    private Double price;
    private Boolean available;
}